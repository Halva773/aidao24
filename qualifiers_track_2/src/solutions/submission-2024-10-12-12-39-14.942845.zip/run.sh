export PATH=/usr/conda/bin:$PATH
python run.py