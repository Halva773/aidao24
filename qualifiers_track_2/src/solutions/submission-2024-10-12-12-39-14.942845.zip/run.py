import numpy as np
import pandas as pd
import pickle
from scripts.data_utils import get_connectome, extract_upper_triangular, sigmoid
from scripts.classification_models import SimpleCatBoost

X = np.load('./data/ts_cut/HCPex/predict.npy')
print(X.shape)
X = get_connectome(X)

indexses = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 101, 102,
            103, 104, 105, 106, 107, 108, 109, 110, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194,
            195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290,
            361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 394,
            395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414]


X = np.array([extract_upper_triangular(mat) for mat in X[:, :, indexses]])

with open('models/catboost_model.pkl', 'rb') as file:
    loaded_model = pickle.load(file)

y_pred = (sigmoid(loaded_model.predict(X)) >= 0.5).astype(int)

print(y_pred)

solution = pd.DataFrame(data=y_pred, columns=['prediction'])
solution.to_csv('./solution.csv', index=False)
